module.exports = {
    parser: '@typescript-eslint/parser',
    extends: ['plugin:@typescript-eslint/recommended', 'plugin:prettier/recommended'],
    env: {
        browser: true,
        node: false,
        es6: true,
    },
    rules: {
        'prettier/prettier': ['error'],
        '@typescript-eslint/no-use-before-define': ['error', { functions: false, classes: false }],
        '@typescript-eslint/explicit-module-boundary-types': 'off',
        '@typescript-eslint/explicit-function-return-type': 'off',
        '@typescript-eslint/explicit-member-accessibility': [
            2,
            {
                accessibility: 'explicit',
                overrides: {
                    constructors: 'no-public',
                },
            },
        ],
        '@typescript-eslint/semi': ['error'],
        // Typescript rules
        '@typescript-eslint/no-parameter-properties': 'off',
        quotes: [
            2,
            'single',
            {
                allowTemplateLiterals: true,
            },
        ],
        '@typescript-eslint/no-unused-vars': ['error'],
        'no-var': 'error',
        'prefer-const': ['off'], // Turn off prefer using const keyword instead of var/let
        // TODO: can improve the rule more, follow https://eslint.org/docs/rules/padding-line-between-statements
        'padding-line-between-statements': [
            'warn',
            {
                blankLine: 'always',
                prev: [
                    'function',
                    'import',
                    'export',
                    'multiline-block-like',
                    'multiline-const',
                    'multiline-expression',
                ],
                next: ['function', 'let', 'const', 'export'],
            },
        ],
    },
};
