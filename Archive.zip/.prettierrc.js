module.exports = {
	semi: true,
	trailingComma: null,
	singleQuote: true,
	printWidth: 120,
	tabWidth: 4,
	useTabs: false
  }