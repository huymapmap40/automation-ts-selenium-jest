export enum TIME_OUT {
    SHORT = 15,
    MEDIUM = 30,
    LONG = 60,
}
