export interface ConfigRunning {
    [key: string]: string;
}

export enum BROWSER {
    CHROME = 'chrome',
    FIREFOX = 'firefox',
    MS_EDGE = 'edge',
    SAFARI = 'safari',
}
