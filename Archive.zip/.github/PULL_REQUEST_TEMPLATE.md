## ⚡️ Summary

-   Contains ticket's link, acceptance criteria, and brief of requirements
-   Ticket: [USXXXX](https://rally1.rallydev.com/#/457810003728d/teamboard?detail=%2Fuserstory%2F476144467176&view=1c432e0b-cc0b-4e84-a8f9-72e357aae78f)
-   Acceptance Criteria: Implement Document Generation On Demand Consumer

## 🏗 Changes

1. Contains what is the code change
2. If there is any special in your changes, it is worth explaining/highlighting.
3. If the changes in frontend code, it should have screenshots.

## ✅ How to test this

1. Contains test instruction for your changes
1. Run `yarn test:all` to run all test scripts and generate test coverage report.

## 🖼 Screenshots

| Before | After |
| ------ | ----- |
| N/A    | N/A   |

## 👷‍♂️ Contributor Checklist

-   [ ] Checked that there are no additional warnings
-   [ ] Code was formatted
-   [ ] Added Github labels
-   [ ] Responsive for table screen
-   [ ] Responsive for mobile screen
-   [ ] A11y

## 🚀 TODO

-   [ ] Any further items need to be implemented.
-   [ ] Set of pull request(s) for a ticket.
